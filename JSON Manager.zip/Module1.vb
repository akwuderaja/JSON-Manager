﻿Module Module1
    Public buyPrice As Double
    Public sellPrice As Double
    Public individual As Double
End Module
